import pygame
import sys
import random  # Required to generate random positions
import asyncio
import math
# Initialize Pygame

async def main():
    pygame.init()


    # Window Setup
    WIDTH, HEIGHT = 800, 600
    SHIP_SPEED = 4
    font = pygame.font.SysFont(None, 24)
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Game")
    clock = pygame.time.Clock()

    player_sprite_surface = pygame.image.load("player.png").convert_alpha()
    player_sprite_surface = pygame.transform.smoothscale(player_sprite_surface, (64, 64))

    # Convert Raw Base64 string back into a Pygame Surface
    player_sprite_surface = pygame.image.load("player.png").convert_alpha()
    player_sprite_surface = pygame.transform.smoothscale(player_sprite_surface, (64,64))
    player_sprite_surface = pygame.transform.rotate(player_sprite_surface, 270)

    ship_position = pygame.Vector2(400, 300)
    angle = 0

    
    # Main Game Loop
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()

        if keys[pygame.K_LEFT]:
            angle += 3

        if keys[pygame.K_RIGHT]:
            angle -= 3

        radians = math.radians(angle)

        forward = pygame.Vector2(
            math.cos(radians),
            -math.sin(radians)
        )

        if keys[pygame.K_UP]:
            ship_position += forward * SHIP_SPEED

        front = ship_position + forward * 20
        left = forward.rotate(140)
        right = forward.rotate(-140)
        p1 = ship_position + forward * 22
        p2 = ship_position + left * 16
        p3 = ship_position + right * 16

        pygame.draw.polygon(
            screen,
            "white",
            [p1, p2, p3],
            2
        )


        if ship_position.x > WIDTH:
            ship_position.x = 0

        if ship_position.x < 0:
            ship_position.x = WIDTH

        if ship_position.y > HEIGHT:
            ship_position.y = 0

        if ship_position.y < 0:
            ship_position.y = HEIGHT


        screen.fill((0,0,0))
        rotated_surface = pygame.transform.rotate(player_sprite_surface, angle)
        screen.blit(rotated_surface, rotated_surface.get_rect(center=ship_position))

        end_point = ship_position + forward * 60
        
        pygame.draw.line(
            screen,
            "red",
            ship_position,
            end_point,
            3
        )

        angle_text = font.render(f"Angle: {angle:.0f}",True,(255,255,255))
        vector_text = font.render(f"Forward: ({forward.x:.2f}, {forward.y:.2f})",True,(255,255,255))
        position_text = font.render(f"Position: ({ship_position.x:.2f}, {ship_position.y:.2f})",True,(255,255,255))
        
        screen.blit(angle_text, (20, 20))
        screen.blit(vector_text, (20, 50))
        screen.blit(position_text, (20, 80))

        # Refresh Screen
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()




if __name__ == "__main__":
    asyncio.run(main())